from airflow import DAG
from airflow.operators.empty import EmptyOperator
from datetime import datetime
with DAG("internet_event_daily_metrics", start_date=datetime(2026,6,1), schedule="@daily", catchup=False) as dag:
    compute_daily_metrics = EmptyOperator(task_id="compute_daily_metrics")
    publish_online = EmptyOperator(task_id="publish_online")
    compute_daily_metrics >> publish_online
