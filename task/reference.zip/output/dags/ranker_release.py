from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.sensors.external_task import ExternalTaskSensor
from airflow.utils.timezone import make_aware


with DAG(
    dag_id='ranker_release',
    start_date=datetime.fromisoformat('2026-04-01T00:00:00+00:00'),
    schedule='0 3 * * *',
    catchup=True,
    max_active_runs=1,
    default_args={'owner': 'ranking'},
) as dag:
    wait_for_features = ExternalTaskSensor(
        task_id='wait_for_features',
        external_dag_id='feature_snapshot',
        external_task_id='publish_snapshot',
        execution_delta=timedelta(minutes=60),
        allowed_states=['success'],
        failed_states=['failed', 'upstream_failed'],
        skipped_states=['skipped'],
        mode='reschedule',
        poll_interval=45,
        timeout=1200,
        check_existence=True,
        soft_fail=False,
        deferrable=False,
    )
    publish_ranker = EmptyOperator(task_id='publish_ranker')

    wait_for_features >> publish_ranker
