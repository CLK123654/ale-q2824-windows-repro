from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.utils.timezone import make_aware


with DAG(
    dag_id='traffic_ingest',
    start_date=datetime.fromisoformat('2026-04-01T00:00:00+00:00'),
    schedule='0 0 * * *',
    catchup=True,
    max_active_runs=1,
    default_args={'owner': 'events'},
) as dag:
    open_partition = EmptyOperator(task_id='open_partition')
    finalize_partition = EmptyOperator(task_id='finalize_partition')

    open_partition >> finalize_partition
