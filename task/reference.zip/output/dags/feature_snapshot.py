from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.sensors.external_task import ExternalTaskSensor
from airflow.utils.timezone import make_aware


with DAG(
    dag_id='feature_snapshot',
    start_date=datetime.fromisoformat('2026-04-01T00:00:00+00:00'),
    schedule='0 2 * * *',
    catchup=True,
    max_active_runs=1,
    default_args={'owner': 'features'},
) as dag:
    wait_for_traffic = ExternalTaskSensor(
        task_id='wait_for_traffic',
        external_dag_id='traffic_ingest',
        external_task_id='finalize_partition',
        execution_delta=timedelta(minutes=120),
        allowed_states=['success'],
        failed_states=['failed', 'upstream_failed'],
        skipped_states=['skipped'],
        mode='reschedule',
        poll_interval=30,
        timeout=900,
        check_existence=True,
        soft_fail=False,
        deferrable=False,
    )
    build_snapshot = EmptyOperator(task_id='build_snapshot')
    publish_snapshot = EmptyOperator(task_id='publish_snapshot')

    wait_for_traffic >> build_snapshot >> publish_snapshot
