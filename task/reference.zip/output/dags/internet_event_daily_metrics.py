from datetime import datetime, timezone

from airflow import DAG
from airflow.operators.empty import EmptyOperator
from airflow.operators.latest_only import LatestOnlyOperator

with DAG(
    dag_id='internet_event_daily_metrics',
    start_date=datetime(2026, 6, 1, tzinfo=timezone.utc),
    schedule='@daily',
    catchup=True,
    max_active_runs=1,
) as dag:
    extract_events = EmptyOperator(task_id='extract_events')
    compute_daily_metrics = EmptyOperator(task_id='compute_daily_metrics', depends_on_past=True)
    quality_gate = EmptyOperator(task_id='quality_gate')
    store_partition = EmptyOperator(task_id='store_partition')
    latest_only = LatestOnlyOperator(task_id='latest_only')
    publish_online = EmptyOperator(task_id='publish_online')

    extract_events >> compute_daily_metrics >> quality_gate >> store_partition >> latest_only >> publish_online
